package com.puput.testsuitmediamobdev.event

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.puput.testsuitmediamobdev.DummyEvent
import com.puput.testsuitmediamobdev.model.EventModel

class EventHorizontalViewModel: ViewModel() {

    fun getHorizontalEvent():List<EventModel> = DummyEvent.generateEventData()
}