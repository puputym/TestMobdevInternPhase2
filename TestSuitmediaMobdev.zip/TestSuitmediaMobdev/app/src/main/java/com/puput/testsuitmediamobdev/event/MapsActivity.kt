package com.puput.testsuitmediamobdev.event

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.puput.testsuitmediamobdev.R
import com.puput.testsuitmediamobdev.adapter.EventHorizontalAdapter
import com.puput.testsuitmediamobdev.databinding.ActivityMapsBinding

class MapsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMapsBinding
    private lateinit var adapterHorizontal :EventHorizontalAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //binding.viewPager.adapter = adapterHorizontal
    }
}