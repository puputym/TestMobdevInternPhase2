package com.puput.testsuitmediamobdev.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.PagerAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.puput.testsuitmediamobdev.R
import com.puput.testsuitmediamobdev.databinding.ListEventHorizontalBinding
import com.puput.testsuitmediamobdev.databinding.ListItemEventBinding
import com.puput.testsuitmediamobdev.model.EventModel
import java.util.ArrayList

class EventHorizontalAdapter(private  val context: Context, private val listEventHorizontal: ArrayList<EventModel> ): PagerAdapter(){

//    private lateinit var onItemClickCallback: OnItemClickCallback
//
//
//    interface OnItemClickCallback {
//        fun onItemClicked(data: EventModel)
//    }
//
//    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
//        this.onItemClickCallback = onItemClickCallback
//    }
//
//    fun setEvent(event: List<EventModel>?) {
//        if (event == null) return
//        this.listEventHorizontal.clear()
//        this.listEventHorizontal.addAll(event)
//    }
//
//    inner class EventHorizontalViewHolder(private val binding: ListEventHorizontalBinding) :
//        RecyclerView.ViewHolder(binding.root) {
//        fun bind(event: EventModel) {
//            with(binding) {
//                Glide.with(itemView.context)
//                    .load(event.img)
//                    .apply(RequestOptions().override(150, 150))
//                    .into(tvImg)
//                eventName.text = event.name
//                itemView.setOnClickListener {
//                    onItemClickCallback.onItemClicked(event)
//                }
//            }
//        }
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventHorizontalViewHolder {
//        val itemHorizontalBinding =
//            ListEventHorizontalBinding.inflate(LayoutInflater.from(parent.context), parent, false)
//        return EventHorizontalViewHolder(itemHorizontalBinding)
//    }
//
//    override fun onBindViewHolder(holder: EventHorizontalViewHolder, position: Int) {
//        holder.bind(listEventHorizontal[position])
//    }
//
//    override fun getItemCount(): Int = listEventHorizontal.size
    override fun getCount(): Int = listEventHorizontal.size

    override fun isViewFromObject(view: View, `object`: Any): Boolean {
        return  view == `object`
    }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val view = LayoutInflater.from(context).inflate(R.layout.list_event_horizontal, container, false)

        val itemHorizontalBinding =
           ListEventHorizontalBinding.inflate(LayoutInflater.from(container.context), container, false)
        val model = listEventHorizontal[position]
        val name = model.name
       // val image = model.img

       //itemHorizontalBinding.tvImg

                Glide.with(context)
                    .load(model.img)
                    .apply(RequestOptions().override(150, 150))
                    .into(itemHorizontalBinding.tvImg)
            itemHorizontalBinding.eventName.text = name

        //container.addView(itemHorizontalBinding, position)

        return itemHorizontalBinding
    }
}