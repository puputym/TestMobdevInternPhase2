package com.puput.testsuitmediamobdev.event

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.puput.testsuitmediamobdev.R
import com.puput.testsuitmediamobdev.adapter.EventHorizontalAdapter
import com.puput.testsuitmediamobdev.databinding.FragmentMapsBinding

class MapsFragment : Fragment() {

    private lateinit var fragment: FragmentMapsBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        fragment = FragmentMapsBinding.inflate(inflater, container, false)
        return fragment.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (activity != null) {
            val eventHorizontalAdapter = EventHorizontalAdapter()
            val viewModel = ViewModelProvider(
                this,
                ViewModelProvider.NewInstanceFactory()
            )[EventHorizontalViewModel::class.java]

                eventHorizontalAdapter.setEvent(viewModel.getHorizontalEvent())
                with(fragment.rvEvent) {
                    layoutManager = LinearLayoutManager(context)
                    setHasFixedSize(true)
                    adapter = eventHorizontalAdapter
//                    movieAdapter.setOnItemClickCallback(object : MovieAdapter.OnItemClickCallback {
//                        override fun onItemClicked(data: ListMovieResponse) {
//                            val intent = Intent(context, DetailMovieActivity::class.java)
//                            intent.putExtra(DetailMovieActivity.EXTRA_DATA, data.id.toString())
//                            intent.putExtra("status", DetailMovieActivity.EXTRA_MOVIE)
//                            startActivity(intent)
//                        }
//
//                    })
                //}
                //fragmentMovieBinding.progressBar.visibility = View.INVISIBLE
            }

        }
    }

}